package Diploma;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.*;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;


public class Processflow
{
    public static void main( String[] args ) throws Exception
    {
//Read the electrical values from the file that is already generated from the Multimeter Software.

        FileReader fileReader = new FileReader("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\Valori electrice.txt");
            BufferedReader reader = new BufferedReader(fileReader);

            String text = "";
            String line = reader.readLine();

            while (line != null) {
                text = text + " " + line;
                line = reader.readLine();
            }
// Write the data stored in the Procesflow.txt.
            PrintWriter output = new PrintWriter("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\ProcesFlow.txt");
            output.print(text);
        System.out.println("1. Valorice electrice au fost actualizate");
        TimeUnit.SECONDS.sleep(1);

// Initiate the request of the values from the barcode.
            String barcodescanner;
            Scanner barcode = new Scanner(System.in);
            System.out.println("2. Scanati va rog codul de bare ... ");
            barcodescanner = barcode.next();
            output.print(" " + barcodescanner);

            TimeUnit.SECONDS.sleep(1);
            output.close();
        System.out.println("3. Fisierul a fost actualizat ...");

        // Copy the result in in aditional folder.

                Path FROM = Paths.get("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\ProcesFlow.txt");
                Path TO = Paths.get("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\Final Results\\FinalResults.txt");

                //overwrite existing file, if exists.
                CopyOption[] options = new CopyOption[]{
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.COPY_ATTRIBUTES
                };
                Files.copy(FROM, TO, options);
                TimeUnit.SECONDS.sleep(1);
        System.out.println("The file was cloned succesfully");
            }
        }

//Create excel file.

        /* File f = new File("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\RezultatValori.xls");

        WritableWorkbook excel = Workbook.createWorkbook(f);
        WritableSheet sheet = excel.createSheet("sheet1",0);

        Label l = new Label(0,0,"data 1");
            sheet.addCell((new Label(0,0,"Numar intern cablu")));
            sheet.addCell((new Label(1,0,"Valoare electrica masurata")));

            sheet.addCell((new Label(0,1,barcodescanner)));

            excel.write();
            excel.close();
*/



