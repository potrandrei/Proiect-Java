package Diploma;

import jdk.swing.interop.SwingInterOpUtils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.*;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;


public class Processflow {
    public static void main(String[] args) throws Exception {
        try {

            //Read the electrical values from the file that is already generated from the Multimeter Software.
            FileReader fileReader = new FileReader("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\Valori electrice.txt");
            BufferedReader reader = new BufferedReader(fileReader);

            String text = "";
            String line = reader.readLine();

            while (line != null) {
                text = text + " " + line;
                line = reader.readLine();
            }

// Write the data stored in the Procesflow.txt.
            PrintWriter output = new PrintWriter("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\ProcesFlow.txt");
            output.print(text);
            System.out.println("1. Valorice electrice au fost actualizate");
            TimeUnit.SECONDS.sleep(1);

// Initiate the request of the values from the barcode.
            String barcodescanner;
            Scanner barcode = new Scanner(System.in);
            System.out.println("2. Scanati va rog codul de bare ... ");
            barcodescanner = barcode.next();
            output.print(" " + barcodescanner);

            TimeUnit.SECONDS.sleep(1);
            output.close();
            System.out.println("3. Fisierul a fost actualizat ...");

            // Copy the result in in aditional folder.

            Path FROM = Paths.get("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\src\\main\\Log\\ProcesFlow.txt");
            Path TO = Paths.get("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\Final Results\\FinalResults.txt");

            //overwrite existing file, if exists.
            CopyOption[] options = new CopyOption[]{
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.COPY_ATTRIBUTES
            };
            Files.copy(FROM, TO, options);
            TimeUnit.SECONDS.sleep(1);
            System.out.println("The file was cloned succesfully");

        }

// Print the messages fro the catch function.
        catch (Exception e) {
            System.out.println("ERROR!");
            System.out.println("       Please do the following steps: ");
            System.out.println("Check if the file with electrical values is updated.");
            System.out.println("Check if the bar code is working.");
            System.out.println("Check if the path for final values is created");
            System.out.println(" ");
            System.out.println(" - After checking please run again the program");
            System.out.println(" - If error persist after checking the steps please call MENTENANCE !!!");

// Exit from the program by pressing any button key.
            Scanner scan = new Scanner(System.in);
            {
                System.out.print("Press any key to continue . . . ");
                scan.nextLine();
                System.exit(0);
            }




//Create excel file.

        /* File f = new File("D:\\Programare\\Programe\\IntelliJ\\Proiect de Diploma\\RezultatValori.xls");

        WritableWorkbook excel = Workbook.createWorkbook(f);
        WritableSheet sheet = excel.createSheet("sheet1",0);

        Label l = new Label(0,0,"data 1");
            sheet.addCell((new Label(0,0,"Numar intern cablu")));
            sheet.addCell((new Label(1,0,"Valoare electrica masurata")));

            sheet.addCell((new Label(0,1,barcodescanner)));

            excel.write();
            excel.close();
*/


        }
    }
}